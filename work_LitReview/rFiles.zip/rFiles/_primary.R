## Primary Script File
## Data Cleaning Book
## Literature Review Data
## Bianca Manago

#***************************************************************************
  
  # NOTE: These are files from a preliminary/practice systematic review 
  #       of the literature. These files match the examples from the book, 
  #       but are not final. We learned a lot from this preliminary review.
  #       For the final systematic review files and paper
  #       see https://biancamanago.com.
  
#***************************************************************************
  
  # Remember to run the _packages.R script first!
  
##########
### Step 1: Identify All Possible Articles	
##########

# Import data from Web of Science and Pro Quest
rmarkdown::render("llr_data00_01_import_webofscience.Rmd")
rmarkdown::render("llr_data00_01_import_proquest.Rmd")

#   Here I identify and remove duplicate articles within each database.
#   I also identify and remove articles that don't fit the 
#   "journal article" criterion.

# Merge datasets
rmarkdown::render("llr_data00_02_append.Rmd")

#   Here I simply combine the two datasets.

# Drop duplicate entries
rmarkdown::render("llr_data00_03_drop.Rmd")

#   Here I identify and remove duplicate articles that occurred 
#   between datasets. There were also some articles that were included 
#   by ProQuest or Web of Science even though they didn't fit our original 
#   search criteria (e.g., published after 2020).

#**************************************************************** 
  # Round 1 Coding
#****************************************************************	
  
##########
### Step 1a: Screen 	
##########

# Import and combine data from coding 
rmarkdown::render("llr_data01a_01_combine.Rmd")

# Identify any missed/uncoded observations & export
rmarkdown::render("llr_data01a_02_uncoded.Rmd")

# Drop articles that do not meet criteria:
# dv is stigma, quant, others perceptions, iv is labeling
rmarkdown::render("llr_data01a_03_screen_drop.Rmd")

#   There were several other rounds of coding, 
#   but all followed this same general format.
