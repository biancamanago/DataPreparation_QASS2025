############################################################
# __packages.R
# Ensure correct R version and install/load required packages
############################################################

# Require minimum R version
if (getRversion() < "4.2.0") {
  stop("❌ Requires R version 4.2.0 or higher.")
}

# Ensure remotes package is installed for install_version
if (!requireNamespace("remotes", quietly = TRUE)) {
  install.packages("remotes")
}
library(remotes)

# Packages and minimum versions (from your Rmd scripts)
required_packages <- list(
  knitr      = "1.45",
  haven      = "2.5.4",
  questionr  = "0.7.7",
  tidyverse  = "2.0.0",
  broom      = "1.0.5",
  here       = "1.0.1",
  expss      = "0.11.6",
  dplyr      = "1.1.4",
  stringr    = "1.5.1",
  readxl     = "1.4.3",
  rmarkdown  = "2.26"
)

# Install/check packages
for (pkg in names(required_packages)) {
  required_version <- required_packages[[pkg]]
  
  if (!requireNamespace(pkg, quietly = TRUE)) {
    message("⬇️ Installing ", pkg, " version ", required_version)
    remotes::install_version(pkg, version = required_version, upgrade = "never")
  }
  
  installed_version <- as.character(packageVersion(pkg))
  
  if (installed_version < required_version) {
    message("⬇️ Upgrading ", pkg, " from ", installed_version, " to ", required_version)
    remotes::install_version(pkg, version = required_version, upgrade = "never")
  }
  
  library(pkg, character.only = TRUE)
  cat("✅", pkg, "version", as.character(packageVersion(pkg)), "\n")
}

cat("✅ All packages installed and loaded successfully!\n")
