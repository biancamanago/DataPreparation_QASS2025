install.packages("rmarkdown")
install.packages("tidyverse")
install.packages("renv")
install.packages("broom")
install.packages("dplyr")
install.packages("expss")
install.packages("haven")
install.packages("here")
install.packages("knitr")
install.packages("naniar")
install.packages("questionr")
install.packages('codebook')
install.packages('Hmisc')
install.packages('psych')
install.packages("sjlabelled")
install.packages('assertive') 
install.packages('desctable')
install.packages('pander')
install.packages('summarytools')

install.packages("BiocManager")
library(BiocManager)
BiocManager::install("graph")
install.packages("ggm")

## optional ##
## You need LaTex to run this

# install.packages("tinytex")
# tinytex::install_tinytex()

