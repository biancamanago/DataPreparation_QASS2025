These examples were not in the book, but I use these example files 
sometimes when I teach workshops about data preparation. 


I hope these are helpful!