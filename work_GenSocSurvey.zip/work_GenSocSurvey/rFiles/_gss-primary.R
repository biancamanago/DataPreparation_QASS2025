## Primary Script File for GSS Data

## Project: Data Cleaning Sage Book
## Author: Bianca Manago 
## Date: 2024-07-24


source("__packages.R")

rmarkdown::render('gss_data01_compile.Rmd')
rmarkdown::render('gss_data02_label.Rmd')
rmarkdown::render('gss_data03_examine.Rmd')
rmarkdown::render('gss_data04_missing.Rmd')
rmarkdown::render('gss_data05_newVars.Rmd')
rmarkdown::render('gss_data06_reexamine.Rmd')